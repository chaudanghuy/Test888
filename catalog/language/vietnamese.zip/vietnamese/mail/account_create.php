<?php
// Text
$_['text_subject']  = '%s - Cảm ơn bạn đã đăng ký 1 tài khoản';
$_['text_welcome']  = 'Chào mừng bạn %s!';
$_['text_login']    = 'Tài khoản của bạn đã được tạo và bạn có thể đăng nhập bằng cách sử dụng địa chỉ email và mật khẩu của bạn bằng cách truy cập website của chúng tôi hoặc tại URL sau đây:';
$_['text_approval'] = 'Tài khoản của bạn phải được phê duyệt trước khi bạn có thể đăng nhập. Khi được chấp nhận, bạn có thể đăng nhập bằng cách sử dụng địa chỉ email và mật khẩu của bạn để truy cập website của chúng tôi hoặc tại URL sau đây:';
$_['text_services'] = 'Sau khi đăng nhập, bạn có thể truy cập các dịch vụ khác bao gồm xem đơn đặt hàng, in hóa đơn, chỉnh sửa thông tin tài khoản của bạn.';
$_['text_thanks']   = 'Cám ơn,';
?>