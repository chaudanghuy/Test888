﻿<?php
// Mail
$_['text_subject']      = '%s - Cập nhật đơn hàng %s';
$_['text_order']        = 'Số đơn hàng:';
$_['text_date_added']   = 'Ngày đặt hàng:';
$_['text_order_status'] = 'Tình trạng đơn hàng của bạn:';
$_['text_comment']      = 'Các ý kiến về đơn hàng của bạn:';
$_['text_invoice']      = 'Để xem đơn hàng của bạn hãy bấm vào liên kết dưới đây:';
$_['text_footer']       = 'Xin vui lòng trả lời email này nếu bạn có bất kỳ câu hỏi nào.';
?>