<?php
// Mail
$_['text_subject']  = '%s - Mật khẩu mới';
$_['text_greeting'] = 'Một mật khẩu mới đã được yêu cầu từ %s.';
$_['text_password'] = 'Mật khẩu mới của bạn là:';
?>