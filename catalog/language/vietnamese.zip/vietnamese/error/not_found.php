﻿<?php
// Heading
$_['heading_title'] = 'Không tìm thấy trang này!';

// Text
$_['text_error']    = 'Không tìm thấy trang này.';
?>