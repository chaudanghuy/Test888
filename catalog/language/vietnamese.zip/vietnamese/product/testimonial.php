<?php
// Heading
$_['heading_title'] = 'Khách hàng chứng thực';

// Text
$_['text_error'] = 'Không tìm thấy trang!';
?>