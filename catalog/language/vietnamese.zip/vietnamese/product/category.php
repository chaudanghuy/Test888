<?php
// Text
$_['text_product']      = 'Các sản phẩm';
$_['text_error']        = 'Không có Danh mục này!';
$_['text_empty']        = 'Không có sản phẩm trong danh mục này.';
$_['text_stars']        = '%s out of 5 Stars!';
$_['text_sort']         = 'Xếp theo:';
$_['text_default']      = 'Mặc định';
$_['text_name_asc']     = 'Tên A - Z';
$_['text_name_desc']    = 'Tên Z - A';
$_['text_price_asc']    = 'Giá Thấp &gt; Cao';
$_['text_price_desc']   = 'Giá Cao &lt Thấp';
$_['text_rating_asc']   = 'Thứ hạng Thấp nhất';
$_['text_rating_desc']  = 'Thứ hạng Cao nhất';
$_['text_model_asc']    = 'Model A - Z';
$_['text_model_desc']   = 'Model Z - A';
?>