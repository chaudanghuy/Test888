<?php
// Heading 
$_['heading_title']  = 'Tất cả sản phẩm với Chỉ Một loại hàng';

// Text
$_['text_limit']        = 'Sản phẩm / Trang:';
$_['text_empty']        = 'Không có sản phẩm trong danh sách.';
$_['text_stars']        = 'hơn 5 Sao!';
$_['text_sort']         = 'Phân loại:';
$_['text_name_asc']     = 'Name A - Z';
$_['text_name_desc']    = 'Name Z - A';
$_['text_price_asc']    = 'Giá thấp : cao';
$_['text_price_desc']   = 'Giá cao : thấp';
$_['text_rating_asc']   = 'Đánh giá thấp nhất'; 
$_['text_rating_desc']  = 'Đánh giá cao nhất';
?>