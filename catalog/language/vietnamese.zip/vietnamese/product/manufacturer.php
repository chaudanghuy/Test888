<?php
// Text
$_['text_product']      = 'Sản phẩm';
$_['text_error']        = 'Không có hãng sản xuất này!';
$_['text_empty']        = 'Không có sản phẩm nào .';
$_['text_stars']        = '%s trong 5 Sao!';
$_['text_sort']         = 'Sắp xếp:';
$_['text_default']      = 'Mặc định';
$_['text_name_asc']     = 'Tên A - Z';
$_['text_name_desc']    = 'Tên Z - A';
$_['text_price_asc']    = 'Giá Thấp &gt; Cao';
$_['text_price_desc']   = 'Giá Cao &lt; Thấp';
$_['text_rating_asc']   = 'Đánh giá Thấp nhất';
$_['text_rating_desc']  = 'Đánh giá cao nhất';
$_['text_model_asc']    = 'Model A - Z';
$_['text_model_desc']   = 'Model Z - A';
?>