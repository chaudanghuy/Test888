<?php
// Heading
$_['heading_title']     = 'Sản phẩm đặc biệt-Khuyến mại';

// Text
$_['text_empty']        = 'Hiện không có sản phẩm nào.';
$_['text_stars']        = '%s trong 5 Sao!';
$_['text_sort']         = 'Xếp theo:';
$_['text_default']      = 'Mặc định';
$_['text_name_asc']     = 'Tên A - Z';
$_['text_name_desc']    = 'Tên Z - A';
$_['text_price_asc']    = 'Giá Thấp &gt; Cao';
$_['text_price_desc']   = 'Giá Cao &lt; Thấp';
$_['text_rating_asc']   = 'Điểm Thấp nhất';
$_['text_rating_desc']  = 'Điểm Cao nhất';
$_['text_model_asc']    = 'Model A - Z';
$_['text_model_desc']   = 'Model Z - A';
?>