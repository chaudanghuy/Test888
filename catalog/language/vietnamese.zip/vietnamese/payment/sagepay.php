<?php
// Text
$_['text_title']       = 'Credit Card / Debit Card (SagePay)';
$_['text_description'] = 'Items on %s Order No: %s';
?>