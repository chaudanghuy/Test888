<?php
// Text
$_['text_title'] 		= 'Credit Card / Debit Card (NoChex)';
$_['text_testmode'] 	= 'Payment Gateway is in Test Mode. Transaction will not be valid';

// Error
$_['error_no_order'] 	= 'No Order ID Found';
$_['error_declined'] 	= 'Payment was declined';
?>