<?php
/*
* DUCLM-NGANLUONG.VN
*/
$_['text_title'] = '<img src="https://www.nganluong.vn/webskins/skins/nganluong/images/nl.gif" /> Thanh toán trực tuyến an toàn qua NgânLượng.vn <a  target="_blank" href="http://help.nganluong.vn/'.str_replace("www.","",$_SERVER['HTTP_HOST']).'.html" title="Hướng dẫn thanh toán qua NgânLượng.vn" style="font-size:11px;text-decoration:none;color:#09F;">[ Hướng dẫn thanh toán ]</a>';
?>