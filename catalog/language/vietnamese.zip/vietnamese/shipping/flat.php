<?php
// Text
$_['text_title']       = 'Đánh giá';
$_['text_description'] = 'Đánh giá vận chuyển';
?>