<?php
// Text
$_['text_title']  = 'Bưu điện Hoa Kỳ';
$_['text_weight'] = 'Trọng lượng:';
$_['text_eta']    = 'Thời gian dự kiến:';
?>