<?php
// Text
$_['text_title']       = 'Theo khoản';
$_['text_description'] = 'Đánh giá theo mức vận chuyển';
?>