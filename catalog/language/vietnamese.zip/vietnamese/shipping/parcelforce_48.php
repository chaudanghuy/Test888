<?php
// Text
$_['text_title']       = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight']      = 'Nặng:';
$_['text_insurance']   = 'Bảo hiểm tối đa:';
$_['text_time']        = 'Dự kiến Thời gian: Trong vòng 48 giờ'; 
?>