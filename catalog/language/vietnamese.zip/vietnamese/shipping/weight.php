<?php
// Text
$_['text_title']  = 'Vận chuyển theo trọng lượng';
$_['text_weight'] = 'Trọng lượng:'; 
?>