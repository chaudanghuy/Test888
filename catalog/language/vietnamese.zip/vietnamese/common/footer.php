<?php
// Text
$_['text_powered_by'] = 'Bản quyền thuộc về &copy; <a href="http://myphamhanquoc.biz/" target="_blank"> %s </a> %s <br />Địa chỉ: 83/17 Bạch Đằng, P.2, Q.Tân Bình, TP.HCM<br>ĐT: 097.464.3919 - 08.688.420.90<br> Design By <a href="http://myphamhanquoc.biz/" target="_blank">myphamhanquoc.biz </a>';
$_['text_home']     = 'Trang chủ';
$_['text_special']  = 'Đặc biệt';
$_['text_account']  = 'Tài khoản';
$_['text_login']    = 'Đăng nhập';
$_['text_logout']   = 'Thoát';
$_['text_cart']     = 'Giỏ hàng';
$_['text_checkout'] = 'Thanh toán';
?>
