<?php
// Heading
$_['heading_title']     = 'Bảo trì hệ thống';

// Text
$_['text_maintenance']  = 'Bảo trì hệ thống';
$_['text_message']      = '<h1 style="text-align:center;">Hiện chúng tôi đang thực hiện một số bảo trì theo lịch trình.<br/>Gian hàng sẽ mở cửa trong thời gian sớm nhất. Vui lòng quay lại sau.</h1>';
?>