<?php
// Heading 
$_['heading_title'] = 'Chào Mừng Tới Myphamhanquoc %s';

// Text
$_['text_latest']   = 'Sản phẩm mới nhất';
?>
