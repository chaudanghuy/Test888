<?php
// Text
$_['text_home']     = 'Trang chủ';
$_['text_special']  = 'Khuyến mại';
$_['text_contact']  = 'Liên hệ';
$_['text_sitemap']  = 'Sơ đồ trang';
$_['text_bookmark'] = 'Đánh dấu';
$_['text_account']  = 'Tài khoản';
$_['text_login']    = 'Đăng nhập';
$_['text_logout']   = 'Thoát';
$_['text_cart']     = 'Giỏ hàng';
$_['text_checkout'] = 'Thanh toán';

$_['text_keyword']  = 'Từ khóa';
$_['text_advanced'] = 'Tìm kiếm nâng cao';
$_['text_category'] = 'Chọn danh mục';

// Entry
$_['entry_search']   = 'Tìm:';
?>
