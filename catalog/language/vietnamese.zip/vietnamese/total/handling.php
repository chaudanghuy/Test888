<?php
$_['text_handling'] = 'Khoản phí:';
?>