<?php
$_['text_low_order_fee'] = 'Đặt hàng chi phí thấp:';
?>