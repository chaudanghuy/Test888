<?php
// Heading 
$_['heading_title']  = 'Đặc Biệt';

// Text
$_['text_stars']     = '%s hơn 5 sao!';
$_['text_products']  = 'Sản Phẩm';
?>