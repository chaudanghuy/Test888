<?php
// Heading
$_['heading_title'] = 'Site Visits';

$_['visitor_counter_label'] = 'Visitor Counter';
?>
