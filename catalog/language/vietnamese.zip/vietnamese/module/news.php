<?php
// Heading 
$_['heading_title']  = 'Tin mới';

// Text
$_['text_read_more'] = 'Chi tiết ';
?>
