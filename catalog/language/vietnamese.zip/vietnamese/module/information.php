<?php
// Heading 
$_['heading_title'] = 'Thông tin ';

// Text
$_['text_contact']  = 'Liên hệ';
$_['text_sitemap']  = 'Sơ đồ trang';
?>