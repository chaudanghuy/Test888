<?php
// Heading 
$_['heading_title']  = 'Sản phẩm';

// Text
$_['text_stars']     = '%s hơn 5 sao!';
$_['text_products']  = '';
?>