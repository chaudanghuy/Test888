<?php
// Heading 
$_['heading_title']  = 'Links';

// Text

?>