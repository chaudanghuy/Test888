<?php
// Heading 
$_['heading_title']  = 'yaSlider';

// Text
$_['text_stars']     = '%s out of 5 Stars!';
$_['text_buy']       = 'Buy';
$_['text_details']   = 'Details';
?>