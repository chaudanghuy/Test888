<?php
// Heading 
$_['heading_title']  = 'Tin Mới Nhất';

// Text
$_['text_read_more'] = 'đọc thêm';
?>
