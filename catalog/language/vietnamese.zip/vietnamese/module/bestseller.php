<?php
// Heading 
$_['heading_title']  = 'Sản phẩm bán chạy';

// Text
$_['text_stars']     = '%s hơn 5 sao!';
?>