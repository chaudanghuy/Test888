<?php
// Heading
$_['heading_title'] = 'Giỏ hàng';

// Text 
$_['text_subtotal'] = 'Tổng tiền:';
$_['text_empty']    = '0 mặt hàng';
$_['text_confirm']  = 'Xác nhận?';
$_['text_remove']   = 'Loại bỏ';
$_['text_view']  	= 'Xem giỏ';
$_['text_checkout'] = 'Thanh toán';
?>