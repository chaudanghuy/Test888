<?php
// Heading 
$_['heading_title']  = 'Trang chủ Danh mục sản phẩm ';

?>