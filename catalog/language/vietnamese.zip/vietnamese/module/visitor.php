<?php

// Heading
$_['heading_title']	= 'Thống kê';

// Texts
$_['text_today']	= 'Hôm nay';
$_['text_week']		= 'Tuần';
$_['text_month']	= 'Tháng';
$_['text_year']		= 'Năm';
$_['text_all']		= 'Tất cả';
$_['text_online']	= 'Online';