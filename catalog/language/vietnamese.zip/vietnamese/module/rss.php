<?php
// Heading 
$_['heading_title']  = 'Tin Mới';

// Text

?>