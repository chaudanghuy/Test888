<?php
// Heading 
$_['heading_title']  = 'Slider';
// Text

?>
