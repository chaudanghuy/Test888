<?php
// Heading 
$_['heading_title']  = 'All Products slidshows';

// Text
$_['text_stars']     = '%s out of 5 Stars!';
?>