<?php
// Heading 
$_['heading_title']  = 'Hỗ trợ trực tuyến';
?>