<?php
// Heading 
$_['heading_title']   = 'Tiêu Đề Tin Tức';

// Text
$_['text_error']	    = 'Chưa có tin tức nào là tốt!';
$_['text_read_more']	 = 'đọc thêm';
$_['text_date_added'] = '<strong>Thêm Ngày:</strong>&nbsp;';

// Buttons
$_['button_latestnews']     = 'Tiêu Đề Tin Tức';
?>
