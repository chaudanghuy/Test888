<?php
// Heading 
$_['heading_title']   = 'Tin tức';

// Text
$_['text_error']	  = 'No News is Good News!';
$_['text_read_more']  = 'Xem chi tiết ';
$_['text_date_added'] = '<strong>Ngày đăng:</strong>&nbsp;';

// Buttons
$_['button_news']     = 'Tin mới';
?>
