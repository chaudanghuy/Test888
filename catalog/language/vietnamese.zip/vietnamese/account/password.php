<?php
// Heading 
$_['heading_title']  = 'Đổi mật khẩu';

// Text
$_['text_account']   = 'Tài khoản';
$_['text_password']  = 'Mật khẩu của bạn';
$_['text_success']   = 'Hoàn tất: Mật khẩu của bạn đã được đổi.';

// Entry
$_['entry_password'] = 'Mật khẩu:';
$_['entry_confirm']  = 'Nhập lại mật khẩu:';

// Error
$_['error_password'] = 'Mật khẩu phải lớn hơn 3 và nhỏ hơn 20 ký tự!';
$_['error_confirm']  = 'Nhập lại mật khẩu phải chính xác!';
?>
