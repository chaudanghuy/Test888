<?php
// Heading 
$_['heading_title']      = 'Tài khoản cá nhân';

// Text
$_['text_account']       = 'Tài khoản';
$_['text_my_account']    ='Tài khoản của bạn';
$_['text_my_orders']     = 'Đơn hàng';
$_['text_my_newsletter'] = 'Thư thông báo';
$_['text_information']   = 'Sửa thông tin';
$_['text_password']      = 'Đổi Mật khẩu';
$_['text_address']       = 'Đổi địa chỉ';
$_['text_history']       = 'Xem các đơn hàng';
$_['text_download']      = 'Tải về';
$_['text_newsletter']    = 'Đăng ký / huỷ bỏ nhận thư thông báo';
?>
