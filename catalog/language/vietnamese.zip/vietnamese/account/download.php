<?php
// Heading 
$_['heading_title']   = 'Tài khoản Tải về';

// Text
$_['text_account']    = 'Tài khoản';
$_['text_downloads']  = 'Tải về';
$_['text_order']      = 'Đơn hàng ID:';
$_['text_date_added'] = 'Ngày:';
$_['text_name']       = 'Tên:';
$_['text_remaining']  = 'Còn lại:';
$_['text_size']       = 'Kích thước:';
$_['text_download']   = 'Download';
$_['text_error']      = 'Bạn không có mục Tải về nào trước đây!';
?>
