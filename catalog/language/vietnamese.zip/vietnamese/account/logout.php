<?php
// Heading 
$_['heading_title'] = 'Thoát khỏi tài khoản';

// Text
$_['text_message']  = '<p>Bạn đã thoát ra khỏi tài khoản.</p><p>Giỏ mua hàng của bạn đã được lưu giữ, các bản ghi bên trong nó sẽ được phục hồi bất cứ khi nào bạn đăng nhập lại vào tài khoản của bạn.</p>';
$_['text_account']  = 'Tài khoản';
$_['text_logout']   = 'Thoát';
?>
