<?php
// Heading 
$_['heading_title']    = 'Thư thông báo';

// Text
$_['text_account']     = 'Tài khoản';
$_['text_newsletter']  = 'Thư thông báo';
$_['text_success']     = 'Hoàn tất: Bạn đã đăng ký xong!';

// Entry
$_['entry_newsletter'] = 'Đăng ký nhận thư:';
?>
