<?php
// Heading 
$_['heading_title']   = 'Lấy lại mật khẩu?';

// Text
$_['text_account']    = 'Tài khoản';
$_['text_forgotten']  = 'Lấy lại mật khẩu';
$_['text_your_email'] = 'Địa chỉ Email của bạn';
$_['text_email']      = 'Nhập địa chỉ Email bạn đã đăng ký. Bấm vào nút "Tiếp tục" Cúng tôi sẽ gửi lại Mật khẩu vào Email cho bạn';
$_['text_success']    = 'Hoàn tất: Mật khẩu mới đã được gửi tới Email của bạn.';

// Entry
$_['entry_email']     = 'Địa chỉ Email:';

// Error
$_['error_email']     = 'Lỗi: Địa chỉ e-mail này không có trong dữ liệu của chúng tôi, xin vui lòng thử lại!';
?>
