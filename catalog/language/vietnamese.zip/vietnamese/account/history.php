<?php
// Heading 
$_['heading_title']   = 'Các đơn hàng trước đây của bạn';

// Text
$_['text_account']    = 'Tài khoản';
$_['text_history']    = 'Các giao dịch trước';
$_['text_order']      = 'Đơn hàng ID:';
$_['text_status']     = 'Trạng thái:';
$_['text_date_added'] = 'Ngày:';
$_['text_customer']   = 'Khách hàng:';
$_['text_products']   = 'Mặt hàng:';
$_['text_total']      = 'Tổng:';
$_['text_error']      = 'Bạn không có đơn đặt hàng trước!';
?>
