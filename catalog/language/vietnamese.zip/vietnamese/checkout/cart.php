<?php
// Heading  
$_['heading_title']   = 'Giỏ hàng';

// Text
$_['text_basket']     = 'Giỏ hàng';
$_['text_sub_total']   = 'Tạm tính:';
$_['text_weight']  	  = 'Trọng lượng giỏ:';
$_['text_error']      = 'Giỏ hàng của bạn hiện không có mặt hàng nào!';

// Column
$_['column_remove']   = 'Loại bỏ';
$_['column_image']    = 'Hình';
$_['column_name']     = 'Tên';
$_['column_model']    = 'Model';
$_['column_quantity'] = 'Số lượng';
$_['column_price']    = 'Đơn giá';
$_['column_total']    = 'Tổng';

// Error
$_['error_stock']     = 'Sản phẩm được đánh dấu với *** không có trong số lượng bạn muốn hoặc không còn trong kho!';
?>