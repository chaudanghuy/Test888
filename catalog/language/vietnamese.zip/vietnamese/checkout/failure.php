<?php
// Heading 
$_['heading_title'] = 'Thanh toán thất bại';

// Text
$_['text_basket']   = 'Giỏ';
$_['text_shipping'] = 'Vận chuyển';
$_['text_payment']  = 'Thanh toán';
$_['text_failure']  = 'Thất bại';
$_['text_message']  = '<p>Có một vấn đề trong quá trình đặt hàng của bạn!</p><p>Nếu vấn đề vẫn còn hãy cố gắng lựa chọn một phương thức thanh toán khác hoặc bạn có thể liên hệ với chủ cửa hàng bằng cách <a href="%s">nhấn vào đây</a>.';
?>
