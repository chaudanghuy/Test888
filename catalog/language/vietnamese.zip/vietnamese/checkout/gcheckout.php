<?php
// Heading
$_['heading_title']  = 'Google Checkout';

// Text
$_['text_gcheckout_title'] = 'Google Checkout';
$_['text_gcheckout_product_id'] = 'sản phẩm #';
$_['text_gcheckout_model'] = 'Model:';
$_['order_status_paid_unconfirmed'] = 'Thanh toán chua được xác nhận';
$_['order_status_pending'] = 'Ðang xem xét.';
$_['order_status_canceled'] = 'Hủy bỏ.';
$_['text_gcheckout_including_all_taxes'] = 'bao gồm tất cả các loại thuế';
$_['text_gcheckout_none'] = 'Không';
$_['text_gcheckout_no_shipping'] = 'Không Vận chuyển theo yêu cầu';
?>