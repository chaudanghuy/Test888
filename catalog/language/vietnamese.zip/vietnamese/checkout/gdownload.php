<?php
// Heading 
$_['heading_title']   = 'Tải từ Google Checkout';

// Text
$_['text_downloads']  = 'Tải về';
$_['text_name']       = 'Tên:';
$_['text_remaining']  = 'Còn lại:';
$_['text_size']       = 'Kích cỡ:';
$_['text_download']   = 'Tải về';
$_['text_error']      = 'Bạn đã không thực hiện bất kỳ đơn đặt hàng tải về trước đó thông qua Google Checkout!';
?>