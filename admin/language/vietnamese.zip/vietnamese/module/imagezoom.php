<?php
// Heading
$_['heading_title']    = 'Phóng to hình';

// Text
$_['text_module']      = 'Mô đun';
$_['text_success']     = 'Thành công: Bạn đã thay đổi mô-đun Phóng to hình!';


// Entry

$_['entry_setting']    ='Thiết lập:';
$_['entry_width']       = 'Chiều rộng:';
$_['entry_height']       = 'Chiều cao:';
$_['entry_status']     = 'Tình trạng:';

// Error
$_['error_permission'] = 'Cảnh báo:Bạn không có quyền sửa đổi Phóng to hình!';

?>