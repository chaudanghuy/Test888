<?php
// Heading
$_['heading_title']    = 'Slideshowshow All Products';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified module All Products';
$_['text_left']        = 'Left';
$_['text_right']       = 'Right';

// Entry
$_['entry_limit']      = 'All Products:';
$_['entry_position']   = 'Position:';
$_['entry_status']     = 'Status:';
$_['entry_sort_order'] = 'Sort Order:';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module Latest!';
?>