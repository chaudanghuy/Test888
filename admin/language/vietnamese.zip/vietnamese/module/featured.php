<?php
// Heading
$_['heading_title']    = 'Nổi bật';

// Text
$_['text_module']      = 'Mô-đun';
$_['text_success']     = 'Thành công: mô-đun Nổi bật đã được thay đổi!';
$_['text_left']        = 'Bên trái';
$_['text_right']       = 'Bên phải';

// Entry
$_['entry_limit']      = 'Hạn chế:';
$_['entry_position']   = 'Vị trí:';
$_['entry_status']     = 'Trạng thái:';
$_['entry_sort_order'] = 'Thứ tự:';
$_['entry_product']    = 'Sản phẩm:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền thay đổi mô-đun Nổi bật!';
?>