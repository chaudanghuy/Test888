<?php
// Heading
$_['heading_title']    = 'Giỏ hàng';

// Text
$_['text_module']      = 'Mô-đun';
$_['text_success']     = 'Hoàn tất: Bạn đã thay đổi mô-đun giỏ hàng!';
$_['text_left']        = 'Bên trái';
$_['text_right']       = 'Bên phải';

// Entry
$_['entry_ajax']       = 'AJAX Thêm vào giỏ:';
$_['entry_position']   = 'Vị trí:';
$_['entry_status']     = 'Trạng thái:';
$_['entry_sort_order'] = 'Thứ tự:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không được phép sửa đổi các mô-đun giỏ hàng!';
?>