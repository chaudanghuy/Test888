<?php

// Heading
$_['heading_title']    = 'Share Module';

// Text
$_['text_module']    = 'Module';
$_['text_success']     = 'Success: You have modified Share Module settings!';
$_['text_left']        = 'Left';
$_['text_right']       = 'Right';

// Entry
$_['entry_status']     = 'Status:';
$_['entry_position']     = 'Position:';
$_['entry_version_status']   = 'Version Status:';
$_['entry_author']	     = 'Author Details:';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Share Module !';
?>
