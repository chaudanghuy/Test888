<?php
// Heading
$_['heading_title']    = 'Google Thống kê';

// Text
$_['text_module']      = 'Mô-đun';
$_['text_success']     = 'Thành công: Mô-đun Google Thống kê đã được thay đổi!';

// Entry
$_['entry_code']       = 'Mã Thống kê:<br /><span class="help">Đăng nhập tài khoản <a onclick="window.open(\'http://www.google.com/analytics/\');"><u>Google Thống kê</u></a> của bạn và tạo hồ sơ cho trang web, sao và dán mã thống kê vào ô trống.</span>';
$_['entry_status']     = 'Trạng thái:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền thay đổi mô-đun Google Thống kê!';
$_['error_code']       = 'Yêu cầu phải có mã';
?>