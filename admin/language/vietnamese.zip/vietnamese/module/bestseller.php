<?php
// Heading
$_['heading_title']    = 'Bán chạy nhất';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Hoàn tất: Bạn đã thay đổi mô-đun bán chạy nhấtt!';
$_['text_left']        = 'Bên trái';
$_['text_right']       = 'Bên phải';

// Entry
$_['entry_limit']      = 'Thời hạn:';
$_['entry_position']   = 'Vị trí:';
$_['entry_status']     = 'Trạng thái:';
$_['entry_sort_order'] = 'Thứ tự:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không được phép sửa đổi mô-đun này!';
?>