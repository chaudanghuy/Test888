<?php
// Heading
$_['heading_title']    = 'SidebarMenu';

// Text
$_['text_module']      = 'Mô - Đun';
$_['text_success']     = 'Thành công: Bạn đã thay đổi mô-đun SidebarMenu!';
$_['text_left']        = 'Trái';
$_['text_right']       = 'Phải';

// Entry
$_['entry_position']   = 'Vị trí:';
$_['entry_status']     = 'Tình trạng:';
$_['entry_sort_order'] = 'Thứ tự sắp xếp:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi SidebarMenu mô-đun!';
?>