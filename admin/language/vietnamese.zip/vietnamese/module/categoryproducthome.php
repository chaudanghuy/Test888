<?php
// Heading
$_['heading_title']    = 'Trang chủ Danh mục sản phẩm 1 ';

// Text
$_['text_module']      = 'Mô - Đun';
$_['text_success']     = 'Thành công: Bạn đã thay đổi mô-đun loại Trang chủ sản phẩm !';
$_['text_left']        = 'Trang chủ';
$_['text_right']       = 'Phải';

// Entry
$_['entry_position']   = 'Vị trí:';
$_['entry_category']   = 'Cây Danh Mục:';
$_['entry_status']     = 'tình Trạng:';
$_['entry_sort_order'] = 'Thứ tự sắp xếp:';
$_['entry_limit']   = 'Số lượng sản phẩm hiển thị:';
$_['entry_headingtitle']   = 'Nhóm Tiêu đề:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền chỉnh sửa mô-đun loại sản phẩm!';
?>