<?php
// Heading
$_['heading_title']    = 'Phụ tổng';

// Text
$_['text_total']       = 'Tổng đặt hàng';
$_['text_success']     = 'Thành công: bạn đã sửa phụ tổng!';

// Entry
$_['entry_status']     = 'Trạng thái:';
$_['entry_sort_order'] = 'Thứ tự:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi phụ tổng!';
?>