<?php
// Heading
$_['heading_title']    = 'Giảm giá';

// Text
$_['text_total']       = 'Tổng đặt hàng';
$_['text_success']     = 'Thành công: Bạn đã thay đổi tổng giảm giá!';

// Entry
$_['entry_status']     = 'Trạng thái:';
$_['entry_sort_order'] = 'Thứ tự:';

// Error
$_['error_permission'] = 'Cảnh báo: bạn không có quyền thay đổi tổng giảm giá!';
?>