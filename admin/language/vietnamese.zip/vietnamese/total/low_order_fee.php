<?php
// Heading
$_['heading_title']    = 'Phí đặt hàng thấp';

// Text
$_['text_total']       = 'Tổng đặt hàng';
$_['text_success']     = 'Thành công: bạn đã thay đổi Phí đặt hàng thấp!';

// Entry
$_['entry_total']      = 'Đặt hàng Tổng số thấp:';
$_['entry_fee']        = 'Phí:';
$_['entry_tax']        = 'Lớp Thuế.:';
$_['entry_status']     = 'Trạng thái:';
$_['entry_sort_order'] = 'Thứ tự:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi Phí đặt hàng thấp!';
?>