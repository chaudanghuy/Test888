<?php
// Heading
$_['heading_title']    = 'Phí xử lý';

// Text
$_['text_total']       = 'Tổng đặt hàng';
$_['text_success']     = 'Thành công: Bạn đã thay đổi phí xử lý!';

// Entry
$_['entry_total']      = 'Tổng đặt hàng:';
$_['entry_fee']        = 'Phí:';
$_['entry_tax']        = 'Loại thuế:';
$_['entry_status']     = 'Trạng thái:';
$_['entry_sort_order'] = 'Thứ tự:';

// Error
$_['error_permission'] = 'Cảnh báo: bạn không có quyền thay đổi phí xử lý!';
?>