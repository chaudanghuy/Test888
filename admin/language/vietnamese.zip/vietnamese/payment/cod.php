<?php
// Heading
$_['heading_title']      = 'Thanh toán tiền mặt';

// Text
$_['text_payment']       = 'Thanh toán';
$_['text_success']       = 'Thành công: Mô-đun thanh toán tiền mặt đã được thay đổi!';
$_['text_development']   = '<span style="color: green;">sẵn sàng</span>';

// Entry
$_['entry_order_status'] = 'Tình trạng đặt hàng:';
$_['entry_geo_zone']     = 'Vùng:';
$_['entry_status']       = 'Tình trạng:';
$_['entry_sort_order']   = 'Thứ tự:';

// Error
$_['error_permission']   = 'Cảnh báo: bạn không có quyền thay đổi kiểu thanh toán tiền mặt!';
?>