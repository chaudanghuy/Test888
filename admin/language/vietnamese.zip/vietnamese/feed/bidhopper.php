<?php
// Heading
$_['heading_title']    = 'BidHopper';

// Text 
$_['text_payment']     = 'Nguồn cấp dữ liệu sản phẩm';
$_['text_success']     = 'Hoàn tất: Bạn đã sửa đổi nguồn cấp dữ liệu BidHopper !';
$_['text_development'] = '<span style="color: red;">Nhà cung cấp</span>';
?>