<?php
// Heading
$_['heading_title']    = 'eDirectory';

// Text 
$_['text_payment']     = 'Nguồn cấp dữ liệu sản phẩm';
$_['text_success']     = 'Hoàn tất: Bạn đã sửa đổi nguồn cấp dữ liệu eDirectory!';
$_['text_development'] = '<span style="color: red;">Nhà cung cấp</span>';
?>