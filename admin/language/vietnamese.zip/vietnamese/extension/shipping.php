<?php
// Heading
$_['heading_title']      = 'Vận chuyển';

// Text
$_['text_install']       = 'Cài đặt';
$_['text_uninstall']     = 'Gỡ bỏ';

// Column
$_['column_name']        = 'Phương thức vận chuyển';
$_['column_status']      = 'Hiện trạng';
$_['column_sort_order']  = 'Thứ tự';
$_['column_action']      = 'Công việc';

// Error
$_['error_permission']  = 'Cảnh báo: Bạn không có quyền sửa đổi vận chuyển!';
?>