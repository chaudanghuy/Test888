<?php
// Heading
$_['heading_title']     = 'Mô đun';

// Text
$_['text_install']      = 'Cài đặt';
$_['text_uninstall']    = 'Gỡ bỏ';
$_['text_left']         = 'Trái';
$_['text_right']        = 'Phải';

// Column
$_['column_name']       = 'Tên Mô đun';
$_['column_position']   = 'Vị trí';
$_['column_status']     = 'Tình trạng';
$_['column_sort_order'] = 'số thứ tự';
$_['column_action']     = 'Công việc';

// Error
$_['error_permission']  = 'Cảnh báo: Bạn không có quyền thay đổi các mô-đun!';
?>