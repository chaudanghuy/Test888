<?php
// Text
$_['text_subject']      = '%s - Đặt hàng cập nhật %s';
$_['text_order']        = 'ID Đặt hàng:';
$_['text_date_added']   = 'Ngày đã đặt hàng:';
$_['text_order_status'] = 'Đặt hàng của bạn đã được cập nhật tình trạng sau đây:';
$_['text_comment']      = 'Các ý kiến cho đặt hàng của bạn là:';
$_['text_invoice']      = 'Để xem đặt hàng của bạn hãy nhấn vào liên kết dưới đây:';
$_['text_footer']       = 'Xin vui lòng trả lời email này nếu bạn có bất cứ câu hỏi.';
?>