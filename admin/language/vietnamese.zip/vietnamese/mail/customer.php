<?php
// Text
$_['text_subject']  = '%s - Tài khoản của bạn đã được kích hoạt!';
$_['text_welcome']  = 'Chào mừng và cám ơn bạn đã đăng ký với %s!';
$_['text_login']    = 'tài khoản của bạn đã được tạo ra và bạn có thể đăng nhập bằng cách sử dụng địa chỉ email và mật khẩu của bạn bằng cách truy cập website của chúng tôi hoặc tại URL sau:';
$_['text_services'] = 'Sau khi đăng nhập, bạn sẽ có thể truy cập các dịch vụ khác bao gồm xem xét đơn đặt hàng qua, in hóa đơn, chỉnh sửa thông tin tài khoản của bạn.';
$_['text_thanks']   = 'Cám ơn,';
?>