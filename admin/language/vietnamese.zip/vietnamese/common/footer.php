<?php
// Text
$_['text_footer'] = '<font color="green"><b>Hỗ trợ bởi <a href="http://www.opencart.com">OpenCart v1.4.9.6</a> &copy; 2009-' . date('Y') . ' toàn quyền. Bản Tiếng Việt của <a href="http://myphamhanquoc.biz/">my pham han quoc</a><br />Phạm Mạnh Tiến - 097 464 3919 - (08)668 420 90 <b></font>';
?>